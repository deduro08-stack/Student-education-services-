Student Education Services App

Default Login:
Username: student
Password: 1234

How to use:
1. Open Android Studio
2. Create Empty Views Activity project
3. Replace MainActivity.java and activity_main.xml with these files
4. Run the app

Dependency:
implementation 'androidx.cardview:cardview:1.0.0'
